var monkey, monkey_running
var banana, bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var survivalTime = 0;
var ground,groundImage,invisibleGround;
function preload() {
groundImage=loadImage("jungle.jpg");
  monkey_running = loadAnimation("sprite_0.png", "sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png", "sprite_7.png", "sprite_8.png")

  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");

}



function setup() {
  createCanvas(600, 400);
  
  ground = createSprite(300, 200, 300, 10);
  ground.velocityX = -4;
  ground.x = ground.width / 2;
  ground.addImage(groundImage);
  ground.scale=1;
  
  invisibleGround=createSprite(300,380,600,20);
  invisibleGround.visible=false;
  
  monkey = createSprite(60, 335,10,10);
  monkey.addAnimation("running", monkey_running);
  monkey.scale = 0.1;

  
  obstacleGroup = createGroup();
  FoodGroup = createGroup();
}


function draw() {
  background("white");
  text("Survival Time:" + survivalTime, 360, 40);
  stroke("white")
  textSize(20);
  fill("white");
  survivalTime = Math.round(frameCount / frameRate())

  
  if (ground.x < 0) {
    ground.x = ground.width / 2;
  }
  if (keyDown("space") && monkey.y >= 261) {
    monkey.velocityY = -12;

  }
  if (FoodGroup.isTouching(monkey)) {
   survivalTime=Math.round(random(10,20,30.40))
if(survivalTime===10){
  monkey.scale=0.12;
}else
{if(survivalTime===20){
  monkey.scale=0.14;
}
    if(survivalTime===30){
  monkey.scale=0.16;
}
    if(survivalTime===40){
  monkey.scale=0.18;
    }
    }
FoodGroup.destroyEach(); 
  }
  if (obstacleGroup.isTouching(monkey)) {
   monkey.scale=monkey.scale=0.08;
  }

  monkey.velocityY = monkey.velocityY + 0.6
 monkey.collide(invisibleGround);

  

 spawnObstacles();
  spawnFood();
  drawSprites();
  
 
}

function spawnObstacles() {
  if (frameCount % 200 === 0) {
    obstacle = createSprite(600, 350);
    obstacle.velocityX = -3;
    obstacle.addImage(obstacleImage);
    obstacle.lifetime = 300;
    obstacleGroup.add(obstacle);
    obstacle.scale = 0.1;

  }
}

function spawnFood() {

  if (frameCount % 170 === 0) {
    banana = createSprite(600, 150);
    banana.y = Math.round(random(200, 300));
    banana.addImage(bananaImage);
    banana.velocityX = -4;
    banana.lifetime = 300;
    FoodGroup.add(banana);
    banana.scale = 0.1;
    FoodGroup.collide(monkey);
  }
}